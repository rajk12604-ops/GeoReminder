package com.erraj.georeminder1;

public class ReminderModel {

    private int id;
    private String reminder;
    private double latitude;
    private double longitude;
    private int radius;

    public ReminderModel(
            int id,
            String reminder,
            double latitude,
            double longitude,
            int radius) {

        this.id = id;
        this.reminder = reminder;
        this.latitude = latitude;
        this.longitude = longitude;
        this.radius = radius;
    }

    public int getId() {
        return id;
    }

    public String getReminder() {
        return reminder;
    }

    public double getLatitude() {
        return latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public int getRadius() {
        return radius;
    }
}