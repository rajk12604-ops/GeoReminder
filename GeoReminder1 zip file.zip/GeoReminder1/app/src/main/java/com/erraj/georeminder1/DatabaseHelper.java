package com.erraj.georeminder1;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.Cursor;

import java.util.ArrayList;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "GeoReminder.db";
    private static final int DATABASE_VERSION = 2;

    public static final String TABLE_NAME = "reminders";

    public static final String COL_ID = "id";
    public static final String COL_NAME = "reminder";
    public static final String COL_LAT = "latitude";
    public static final String COL_LNG = "longitude";
    public static final String COL_RADIUS = "radius";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String query = "CREATE TABLE " + TABLE_NAME + "("
                + COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COL_NAME + " TEXT,"
                + COL_LAT + " REAL,"
                + COL_LNG + " REAL,"
                + COL_RADIUS + " INTEGER"
                + ")";

        db.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE " + TABLE_NAME
                    + " ADD COLUMN " + COL_RADIUS + " INTEGER DEFAULT 100");
        }
    }

    public boolean insertReminder(
            String reminder,
            double latitude,
            double longitude,
            int radius) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(COL_NAME, reminder);
        values.put(COL_LAT, latitude);
        values.put(COL_LNG, longitude);
        values.put(COL_RADIUS, radius);

        long result = db.insert(TABLE_NAME, null, values);

        return result != -1;
    }

    public ArrayList<ReminderModel> getAllReminders() {

        ArrayList<ReminderModel> reminderList = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_NAME,
                null
        );

        if (cursor.moveToFirst()) {

            do {

                int id = cursor.getInt(
                        cursor.getColumnIndexOrThrow(COL_ID)
                );

                String reminder = cursor.getString(
                        cursor.getColumnIndexOrThrow(COL_NAME)
                );

                double latitude = cursor.getDouble(
                        cursor.getColumnIndexOrThrow(COL_LAT)
                );

                double longitude = cursor.getDouble(
                        cursor.getColumnIndexOrThrow(COL_LNG)
                );

                int radius = cursor.getInt(
                        cursor.getColumnIndexOrThrow(COL_RADIUS)
                );

                reminderList.add(
                        new ReminderModel(
                                id,
                                reminder,
                                latitude,
                                longitude,
                                radius
                        )
                );

            } while (cursor.moveToNext());
        }

        cursor.close();

        return reminderList;
    }

    public boolean updateReminder(int id, String reminder) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COL_NAME, reminder);

        int result = db.update(
                TABLE_NAME,
                values,
                COL_ID + "=?",
                new String[]{String.valueOf(id)}
        );

        return result > 0;
    }

    public boolean deleteReminder(int id) {

        SQLiteDatabase db = this.getWritableDatabase();

        int result = db.delete(
                TABLE_NAME,
                COL_ID + "=?",
                new String[]{String.valueOf(id)}
        );

        return result > 0;
    }
}