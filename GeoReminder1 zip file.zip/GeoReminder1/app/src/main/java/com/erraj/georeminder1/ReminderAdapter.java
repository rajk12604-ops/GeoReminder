package com.erraj.georeminder1;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.app.AlertDialog;
import android.content.Context;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ReminderAdapter extends RecyclerView.Adapter<ReminderAdapter.ViewHolder> {

    ArrayList<ReminderModel> reminderList;          
    Context context;

    public ReminderAdapter(Context context, ArrayList<ReminderModel> reminderList) {

        this.context = context;
        this.reminderList = reminderList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_reminder, parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        ReminderModel model = reminderList.get(position);

        holder.txtReminder.setText(model.getReminder());

        holder.txtLocation.setText(
                "Lat: " + model.getLatitude() +
                        "\nLng: " + model.getLongitude()
        );
        holder.itemView.setOnLongClickListener(v -> {

            String[] options = {"Edit", "Delete"};

            new AlertDialog.Builder(context)
                    .setTitle("Choose Action")
                    .setItems(options, (dialog, which) -> {

                        if (which == 0) {

                            EditText editText = new EditText(context);
                            editText.setText(model.getReminder());

                            new AlertDialog.Builder(context)
                                    .setTitle("Edit Reminder")
                                    .setView(editText)
                                    .setPositiveButton("Update", (d, w) -> {

                                        DatabaseHelper db =
                                                new DatabaseHelper(context);

                                        boolean result =
                                                db.updateReminder(
                                                        model.getId(),
                                                        editText.getText().toString()
                                                );

                                        if (result) {

                                            ReminderModel updatedModel = new ReminderModel(
                                                    model.getId(),
                                                    editText.getText().toString(),
                                                    model.getLatitude(),
                                                    model.getLongitude(),
                                                    model.getRadius()
                                            );

                                            reminderList.set(position, updatedModel);

                                            notifyItemChanged(position);

                                            Toast.makeText(context,
                                                    "Reminder Updated",
                                                    Toast.LENGTH_SHORT).show();
                                        }

                                    })
                                    .setNegativeButton("Cancel", null)
                                    .show();

                        } else {

                            new AlertDialog.Builder(context)
                                    .setTitle("Delete Reminder")
                                    .setMessage("Are you sure you want to delete this reminder?")
                                    .setPositiveButton("Delete", (dialog1, which1) -> {

                                        DatabaseHelper db = new DatabaseHelper(context);

                                        boolean result = db.deleteReminder(model.getId());

                                        if (result) {
                                            reminderList.remove(position);
                                            notifyItemRemoved(position);

                                            Toast.makeText(context,
                                                    "Reminder Deleted",
                                                    Toast.LENGTH_SHORT).show();
                                        }

                                    })
                                    .setNegativeButton("Cancel", null)
                                    .show();
                        }

                    })
                    .show();

            return true;
        });
    }

    @Override
    public int getItemCount() {
        return reminderList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        TextView txtReminder, txtLocation;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            txtReminder = itemView.findViewById(R.id.txtReminder);
            txtLocation = itemView.findViewById(R.id.txtLocation);
        }
    }
}