package com.erraj.georeminder1;

public class Reminder {

    private int id;
    private String reminder;
    private double latitude;
    private double longitude;

    public Reminder() {
    }

    public Reminder(String reminder, double latitude, double longitude) {
        this.reminder = reminder;
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getReminder() {
        return reminder;
    }

    public void setReminder(String reminder) {
        this.reminder = reminder;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }
}