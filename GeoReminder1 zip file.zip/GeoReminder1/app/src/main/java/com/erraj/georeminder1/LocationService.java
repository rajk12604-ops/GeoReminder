package com.erraj.georeminder1;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Build;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;

import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.Priority;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class LocationService extends Service {

    private static final String CHANNEL_ID = "GeoReminderAlertChannel";
    private static final int SERVICE_NOTIFICATION_ID = 1;

    private FusedLocationProviderClient fusedLocationClient;
    private LocationCallback locationCallback;
    private DatabaseHelper databaseHelper;

    // Already notified reminders
    private final Set<Integer> notifiedReminders = new HashSet<>();

    @Override
    public void onCreate() {
        super.onCreate();

        createNotificationChannel();

        Notification notification =
                new NotificationCompat.Builder(this, CHANNEL_ID)
                        .setContentTitle("Geo Reminder")
                        .setContentText("Location monitoring is running...")
                        .setSmallIcon(R.mipmap.ic_launcher)
                        .setOngoing(true)
                        .build();

        startForeground(SERVICE_NOTIFICATION_ID, notification);

        fusedLocationClient =
                LocationServices.getFusedLocationProviderClient(this);

        databaseHelper = new DatabaseHelper(this);

        startLocationUpdates();
    }

    private void createNotificationChannel() {       

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

            NotificationChannel channel =
                    new NotificationChannel(
                            CHANNEL_ID,
                            "Geo Reminder",
                            NotificationManager.IMPORTANCE_HIGH
                    );

            channel.setDescription(
                    "Notifications for location based reminders"
            );

            NotificationManager manager =
                    getSystemService(NotificationManager.class);

            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }

    private void startLocationUpdates() {

        LocationRequest locationRequest =
                new LocationRequest.Builder(
                        Priority.PRIORITY_HIGH_ACCURACY,
                        5000
                )
                        .setMinUpdateIntervalMillis(3000)
                        .build();

        locationCallback = new LocationCallback() {

            @Override
            public void onLocationResult(LocationResult locationResult) {

                if (locationResult == null ||
                        locationResult.getLastLocation() == null) {
                    return;
                }

                Location currentLocation =
                        locationResult.getLastLocation();

                double latitude =
                        currentLocation.getLatitude();

                double longitude =
                        currentLocation.getLongitude();

                ArrayList<ReminderModel> reminderList =
                        databaseHelper.getAllReminders();

                for (ReminderModel reminder : reminderList) {

                    Location reminderLocation =
                            new Location("Reminder");

                    reminderLocation.setLatitude(
                            reminder.getLatitude()
                    );

                    reminderLocation.setLongitude(
                            reminder.getLongitude()
                    );

                    float distance =
                            currentLocation.distanceTo(reminderLocation);

                    Log.d(
                            "GeoReminder",
                            reminder.getReminder()
                                    + " Distance: "
                                    + distance
                                    + " meters"
                    );

                    int reminderId = reminder.getId();

                    if (distance <= reminder.getRadius()) {

                        Log.d(
                                "GeoReminder",
                                "Reached: "
                                        + reminder.getReminder()
                        );

                        // Notification only once while inside radius
                        if (!notifiedReminders.contains(reminderId)) {

                            showNotification(
                                    reminder.getId(),
                                    reminder.getReminder()
                            );

                            notifiedReminders.add(reminderId);
                        }

                    } else {

                        // Allow notification again after leaving radius
                        notifiedReminders.remove(reminderId);
                    }
                }

                Log.d(
                        "GeoReminder",
                        "Current Location: "
                                + latitude
                                + ", "
                                + longitude
                );
            }
        };

        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
        ) != PackageManager.PERMISSION_GRANTED
                &&
                ActivityCompat.checkSelfPermission(
                        this,
                        Manifest.permission.ACCESS_COARSE_LOCATION
                ) != PackageManager.PERMISSION_GRANTED) {

            Log.e(
                    "GeoReminder",
                    "Location permission not granted"
            );

            stopSelf();
            return;
        }

        fusedLocationClient.requestLocationUpdates(
                locationRequest,
                locationCallback,
                Looper.getMainLooper()
        );
    }

    private void showNotification(
            int reminderId,
            String reminderName) {

        Intent intent =
                new Intent(this, MainActivity.class);

        PendingIntent pendingIntent =
                PendingIntent.getActivity(
                        this,
                        reminderId,
                        intent,
                        PendingIntent.FLAG_UPDATE_CURRENT
                                | PendingIntent.FLAG_IMMUTABLE
                );

        Notification notification =
                new NotificationCompat.Builder(
                        this,
                        CHANNEL_ID
                )
                        .setSmallIcon(R.mipmap.ic_launcher)
                        .setContentTitle("📍 Geo Reminder")
                        .setContentText(
                                "Reminder: " + reminderName
                        )
                        .setContentIntent(pendingIntent)
                        .setAutoCancel(true)
                        .setPriority(
                                NotificationCompat.PRIORITY_HIGH
                        )
                        .build();

        NotificationManager manager =
                (NotificationManager)
                        getSystemService(NOTIFICATION_SERVICE);

        if (manager != null) {

            manager.notify(
                    1000 + reminderId,
                    notification
            );
        }
    }

    @Override
    public void onDestroy() {

        if (fusedLocationClient != null
                && locationCallback != null) {

            fusedLocationClient.removeLocationUpdates(
                    locationCallback
            );
        }

        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}