package com.erraj.georeminder1;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;

public class AddReminderActivity extends AppCompatActivity {

    EditText etReminder;
    Button btnSave;
    Button btnSelectLocation;
    TextView tvLocation;
    Spinner spinnerRadius;

    String selectedRadius;

    DatabaseHelper databaseHelper;
    FusedLocationProviderClient fusedLocationClient;

    double latitude = 0;
    double longitude = 0;

    private static final int LOCATION_PERMISSION_REQUEST = 100;

    private int getRadiusInMeters() {

        if (selectedRadius.equals("100 meters")) {
            return 100;

        } else if (selectedRadius.equals("200 meters")) {
            return 200;

        } else if (selectedRadius.equals("500 meters")) {
            return 500;

        } else if (selectedRadius.equals("1 kilometer")) {
            return 1000;
        }

        return 100;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_reminder);

        databaseHelper = new DatabaseHelper(this);

        fusedLocationClient =
                LocationServices.getFusedLocationProviderClient(this);

        ViewCompat.setOnApplyWindowInsetsListener(
                findViewById(R.id.main),
                (v, insets) -> {

                    Insets systemBars =
                            insets.getInsets(
                                    WindowInsetsCompat.Type.systemBars()
                            );

                    v.setPadding(
                            systemBars.left,
                            systemBars.top,
                            systemBars.right,
                            systemBars.bottom
                    );

                    return insets;
                }
        );

        // Find Views
        etReminder = findViewById(R.id.etReminder);
        btnSelectLocation = findViewById(R.id.btnSelectLocation);
        tvLocation = findViewById(R.id.tvLocation);
        spinnerRadius = findViewById(R.id.spinnerRadius);
        btnSave = findViewById(R.id.btnSave);

        // Radius options
        String[] radiusOptions = {
                "100 meters",
                "200 meters",
                "500 meters",
                "1 kilometer"
        };

        ArrayAdapter<String> radiusAdapter =
                new ArrayAdapter<>(
                        this,
                        android.R.layout.simple_spinner_item,
                        radiusOptions
                );

        radiusAdapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
        );

        spinnerRadius.setAdapter(radiusAdapter);

        spinnerRadius.setOnItemSelectedListener(
                new android.widget.AdapterView.OnItemSelectedListener() {

                    @Override
                    public void onItemSelected(
                            android.widget.AdapterView<?> parent,
                            android.view.View view,
                            int position,
                            long id) {

                        selectedRadius = radiusOptions[position];
                    }

                    @Override
                    public void onNothingSelected(
                            android.widget.AdapterView<?> parent) {
                    }
                }
        );

        // Select Location button
        btnSelectLocation.setOnClickListener(v -> {

            if (ActivityCompat.checkSelfPermission(
                    this,
                    Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
                    &&
                    ActivityCompat.checkSelfPermission(
                            this,
                            Manifest.permission.ACCESS_COARSE_LOCATION
                    ) != PackageManager.PERMISSION_GRANTED) {

                ActivityCompat.requestPermissions(
                        this,
                        new String[]{
                                Manifest.permission.ACCESS_FINE_LOCATION,
                                Manifest.permission.ACCESS_COARSE_LOCATION
                        },
                        LOCATION_PERMISSION_REQUEST
                );

                return;
            }

            getCurrentLocation();
        });

        // Save Reminder
        btnSave.setOnClickListener(v -> {

            String reminder =
                    etReminder.getText().toString().trim();

            if (reminder.isEmpty()) {

                Toast.makeText(
                        this,
                        "Please Enter Reminder",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            // Location check
            if (latitude == 0 && longitude == 0) {

                Toast.makeText(
                        this,
                        "Please Select Location First",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            int radius = getRadiusInMeters();

            boolean result =
                    databaseHelper.insertReminder(
                            reminder,
                            latitude,
                            longitude,
                            radius
                    );

            if (result) {

                Toast.makeText(
                        this,
                        "Reminder Saved Successfully",
                        Toast.LENGTH_SHORT
                ).show();

                finish();

            } else {

                Toast.makeText(
                        this,
                        "Failed to Save Reminder",
                        Toast.LENGTH_SHORT
                ).show();
            }
        });
    }

    private void getCurrentLocation() {

        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
        ) != PackageManager.PERMISSION_GRANTED
                &&
                ActivityCompat.checkSelfPermission(
                        this,
                        Manifest.permission.ACCESS_COARSE_LOCATION
                ) != PackageManager.PERMISSION_GRANTED) {

            return;
        }

        Toast.makeText(
                this,
                "Getting current location...",
                Toast.LENGTH_SHORT
        ).show();

        fusedLocationClient
                .getLastLocation()
                .addOnSuccessListener(location -> {

                    if (location != null) {

                        latitude = location.getLatitude();
                        longitude = location.getLongitude();

                        tvLocation.setText(
                                "Latitude: " + latitude +
                                        "\nLongitude: " + longitude
                        );

                        Toast.makeText(
                                this,
                                "Location Selected",
                                Toast.LENGTH_SHORT
                        ).show();

                    } else {

                        tvLocation.setText(
                                "Unable to get location"
                        );

                        Toast.makeText(
                                this,
                                "Location not available. Please turn ON GPS.",
                                Toast.LENGTH_LONG
                        ).show();
                    }
                });
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            String[] permissions,
            int[] grantResults) {

        super.onRequestPermissionsResult(
                requestCode,
                permissions,
                grantResults
        );

        if (requestCode == LOCATION_PERMISSION_REQUEST) {

            if (grantResults.length > 0
                    &&
                    grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                getCurrentLocation();

            } else {

                Toast.makeText(
                        this,
                        "Location permission is required",
                        Toast.LENGTH_LONG
                ).show();
            }
        }
    }
}